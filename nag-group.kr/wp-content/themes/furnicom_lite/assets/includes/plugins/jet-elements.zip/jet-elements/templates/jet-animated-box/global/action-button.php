<?php
/**
 * Animated box action button
 */
?>
<a class="elementor-button elementor-size-md jet-animated-box__button jet-animated-box__button--back" href="<?php echo $this->__html( 'back_side_button_link' ); ?>"><?php
	echo $this->__html( 'back_side_button_text' );
?></a>

